To restore this sample database run in the same directory as this readme:
mongorestore -h localhost:27017
