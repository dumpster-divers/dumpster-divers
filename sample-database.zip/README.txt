To restore this sample database:
mongorestore -h localhost:27017

Then run: (Provided you have no environment variables setup)
npm start

